import { 
  users, 
  type User, 
  type InsertUser, 
  type ContactSubmission, 
  type InsertContactSubmission,
  type Review,
  type InsertReview,
  type Blog,
  type InsertBlog,
  type Project,
  type InsertProject
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getAllContactSubmissions(): Promise<ContactSubmission[]>;
  createReview(review: InsertReview): Promise<Review>;
  getAllReviews(): Promise<Review[]>;
  getApprovedReviews(): Promise<Review[]>;
  createBlog(blog: InsertBlog): Promise<Blog>;
  getAllBlogs(): Promise<Blog[]>;
  getPublishedBlogs(): Promise<Blog[]>;
  getBlogById(id: number): Promise<Blog | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  getAllProjects(): Promise<Project[]>;
  getFeaturedProjects(): Promise<Project[]>;
  getProjectById(id: number): Promise<Project | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contactSubmissions: Map<number, ContactSubmission>;
  private reviews: Map<number, Review>;
  private blogs: Map<number, Blog>;
  private projects: Map<number, Project>;
  currentId: number;
  currentContactId: number;
  currentReviewId: number;
  currentBlogId: number;
  currentProjectId: number;

  constructor() {
    this.users = new Map();
    this.contactSubmissions = new Map();
    this.reviews = new Map();
    this.blogs = new Map();
    this.projects = new Map();
    this.currentId = 1;
    this.currentContactId = 1;
    this.currentReviewId = 1;
    this.currentBlogId = 1;
    this.currentProjectId = 1;
    
    // Initialize with sample data for Blackhorse Furnitures
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample reviews
    const sampleReviews: InsertReview[] = [
      { name: "Priya Sharma", rating: 5, comment: "Absolutely stunning furniture quality! Blackhorse Furnitures transformed our Hyderabad villa with authentic Indian craftsmanship.", location: "Hyderabad" },
      { name: "Rajesh Kumar", rating: 5, comment: "The dining set we ordered exceeded expectations. Beautifully handcrafted with premium wood and brass fittings.", location: "Mumbai" },
      { name: "Anita Gupta", rating: 4, comment: "Exceptional service and timely delivery. The bedroom furniture has that perfect blend of traditional and modern design.", location: "Delhi" },
      { name: "Vikram Singh", rating: 5, comment: "Best investment for our Goa villa. The casual seating collection is both comfortable and visually striking.", location: "Goa" }
    ];

    sampleReviews.forEach(review => {
      const id = this.currentReviewId++;
      this.reviews.set(id, { ...review, id, isApproved: true, createdAt: new Date() });
    });

    // Sample blogs
    const sampleBlogs: InsertBlog[] = [
      {
        title: "The Art of Indian Furniture Craftsmanship",
        content: "Indian furniture craftsmanship represents centuries of tradition, skill, and artistic excellence. At Blackhorse Furnitures, we celebrate this heritage by creating pieces that blend traditional techniques with contemporary design...",
        excerpt: "Explore the rich heritage of Indian woodworking and how Blackhorse Furnitures preserves these traditions.",
        author: "Amar Chauhan",
        category: "Craftsmanship"
      },
      {
        title: "Designing Luxury Villas: Hyderabad Project Showcase",
        content: "Our recent project in Hyderabad showcases how premium Indian furniture can transform modern living spaces. From custom dining sets to luxurious bedroom collections...",
        excerpt: "A detailed look at our award-winning Hyderabad villa project featuring premium Indian furniture collections.",
        author: "Diksha Shiring",
        category: "Projects"
      }
    ];

    sampleBlogs.forEach(blog => {
      const id = this.currentBlogId++;
      this.blogs.set(id, { 
        ...blog, 
        id, 
        isPublished: true, 
        createdAt: new Date(), 
        updatedAt: new Date() 
      });
    });

    // Sample projects
    const sampleProjects: InsertProject[] = [
      {
        title: "Luxury Villa Interior - Hyderabad",
        description: "Complete furniture solution for a 5000 sq ft luxury villa featuring handcrafted living room sets, premium dining furniture, and custom bedroom collections.",
        location: "Hyderabad",
        category: "Residential",
        budget: "2500000",
        duration: "3 months",
        images: ["img8.png", "img13.png", "img24.png"],
        completedAt: new Date("2024-03-15")
      },
      {
        title: "Coastal Villa Furnishing - Goa",
        description: "Sophisticated casual furniture collection for a beachside villa, combining comfort with elegant Indian design elements.",
        location: "Goa",
        category: "Residential",
        budget: "1800000",
        duration: "2 months",
        images: ["img17.png", "img19.png", "img22.png"],
        completedAt: new Date("2024-05-20")
      }
    ];

    sampleProjects.forEach(project => {
      const id = this.currentProjectId++;
      this.projects.set(id, { 
        ...project, 
        id, 
        isFeatured: true, 
        createdAt: new Date() 
      });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = this.currentContactId++;
    const submission: ContactSubmission = { 
      ...insertSubmission, 
      id, 
      phone: insertSubmission.phone || null,
      createdAt: new Date() 
    };
    this.contactSubmissions.set(id, submission);
    return submission;
  }

  async getAllContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values());
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const review: Review = { 
      ...insertReview, 
      id, 
      isApproved: false,
      createdAt: new Date() 
    };
    this.reviews.set(id, review);
    return review;
  }

  async getAllReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values());
  }

  async getApprovedReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(review => review.isApproved);
  }

  async createBlog(insertBlog: InsertBlog): Promise<Blog> {
    const id = this.currentBlogId++;
    const blog: Blog = { 
      ...insertBlog, 
      id, 
      isPublished: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.blogs.set(id, blog);
    return blog;
  }

  async getAllBlogs(): Promise<Blog[]> {
    return Array.from(this.blogs.values());
  }

  async getPublishedBlogs(): Promise<Blog[]> {
    return Array.from(this.blogs.values()).filter(blog => blog.isPublished);
  }

  async getBlogById(id: number): Promise<Blog | undefined> {
    return this.blogs.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { 
      ...insertProject, 
      id, 
      isFeatured: false,
      createdAt: new Date()
    };
    this.projects.set(id, project);
    return project;
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getFeaturedProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.isFeatured);
  }

  async getProjectById(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
}

export const storage = new MemStorage();
