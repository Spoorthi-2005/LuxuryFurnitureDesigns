import { motion } from "framer-motion";
import { ArrowRight, Eye, Heart } from "lucide-react";
import { useState } from "react";
import img12 from "@assets/img12.png";
import img13 from "@assets/img13.png";
import img14 from "@assets/img14.png";
import img7 from "@assets/img7.png";
import img8 from "@assets/img8.png";
import img9 from "@assets/img9.png";
import img17 from "@assets/img17.png";

interface CollectionsSectionProps {
  onImageClick: (image: { src: string; alt: string }) => void;
}

export default function CollectionsSection({ onImageClick }: CollectionsSectionProps) {
  const [activeCategory, setActiveCategory] = useState("living");

  const categories = [
    { id: "living", label: "Living Area", icon: "🛋️" },
    { id: "dining", label: "Dining Area", icon: "🍽️" },
    { id: "bedroom", label: "Bedrooms", icon: "🛏️" },
    { id: "casual", label: "Casual Furniture", icon: "🪑" }
  ];

  const collections = {
    living: [
      {
        id: 1,
        title: "Luxe Comfort Series",
        description: "Handcrafted seating with quilted leather upholstery and brass detailing.",
        price: "From ₹85,000",
        image: img12,
        alt: "Premium upholstered dining chairs with quilted design",
        category: "Premium Seating"
      },
      {
        id: 2,
        title: "Contemporary Sectionals",
        description: "Modern L-shaped sofas perfect for open living spaces.",
        price: "From ₹1,25,000",
        image: img13,
        alt: "Contemporary sectional sofas in modern living room",
        category: "Living Room"
      },
      {
        id: 3,
        title: "Accent Collection",
        description: "Statement chairs with distinctive patterns and premium fabrics.",
        price: "From ₹45,000",
        image: img14,
        alt: "Stylish accent chair with marble side table",
        category: "Accent Pieces"
      }
    ],
    dining: [
      {
        id: 4,
        title: "Executive Seating",
        description: "Elegant dining chairs with gold-finished frames and luxurious upholstery.",
        price: "From ₹15,000",
        image: img7,
        alt: "Premium dining chairs with gold frame",
        category: "Dining Chairs"
      },
      {
        id: 5,
        title: "Harmony Collection",
        description: "Complete dining room set with matching sofa and coffee table.",
        price: "From ₹2,50,000",
        image: img8,
        alt: "Complete living room furniture set",
        category: "Dining Sets"
      }
    ],
    bedroom: [
      {
        id: 6,
        title: "Blush Elegance",
        description: "Contemporary curved sectional in premium blush fabric.",
        price: "From ₹1,80,000",
        image: img9,
        alt: "Pink curved sectional sofa in factory setting",
        category: "Bedroom Seating"
      }
    ],
    casual: [
      {
        id: 7,
        title: "Vintage Comfort",
        description: "Retro-inspired seating with rich velvet upholstery.",
        price: "From ₹35,000",
        image: img17,
        alt: "Yellow velvet chairs with cane back design",
        category: "Casual Seating"
      }
    ]
  };

  return (
    <section id="collections" className="py-20 bg-gradient-to-br from-amber-50/50 to-orange-50/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-6xl font-playfair font-bold text-gray-900 mb-6">
            Curated <span className="gradient-text">Collections</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover our handpicked furniture collections, each piece meticulously crafted to reflect contemporary Indian design excellence.
          </p>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                activeCategory === category.id
                  ? "bg-gradient-to-r from-yellow-400 to-amber-500 text-white shadow-lg"
                  : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-200"
              }`}
            >
              <span className="mr-2">{category.icon}</span>
              {category.label}
            </button>
          ))}
        </motion.div>

        {/* Collections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {collections[activeCategory as keyof typeof collections]?.map((collection, index) => (
            <motion.div
              key={collection.id}
              className="group relative perspective-1000"
              initial={{ opacity: 0, y: 40, rotateX: 15 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
            >
              <div className="furniture-card rounded-2xl overflow-hidden transform-3d transition-all duration-500 group-hover:rotate-y-6">
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img
                    src={collection.image}
                    alt={collection.alt}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Hover Actions */}
                  <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-4 group-hover:translate-x-0">
                    <button
                      onClick={() => onImageClick({ src: collection.image, alt: collection.alt })}
                      className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-gray-700 hover:bg-white transition-colors"
                    >
                      <Eye size={16} />
                    </button>
                    <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-red-500 hover:bg-white transition-colors">
                      <Heart size={16} />
                    </button>
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-medium text-gray-700">
                      {collection.category}
                    </span>
                  </div>
                </div>

                <div className="p-6 relative">
                  <h3 className="text-2xl font-playfair font-semibold text-gray-900 mb-3 group-hover:text-yellow-600 transition-colors">
                    {collection.title}
                  </h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {collection.description}
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-yellow-600 font-bold text-lg">
                      {collection.price}
                    </span>
                    <button className="flex items-center gap-2 text-gray-700 hover:text-yellow-600 transition-colors group/btn">
                      <span className="text-sm font-medium">View Details</span>
                      <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <p className="text-gray-600 mb-6">Ready to transform your space with bespoke furniture?</p>
          <button className="bg-gradient-to-r from-yellow-400 to-amber-500 text-white px-8 py-4 rounded-full font-semibold hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            Request Custom Design
          </button>
        </motion.div>
      </div>
    </section>
  );
}
