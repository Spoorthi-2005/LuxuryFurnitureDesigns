import { motion } from "framer-motion";
import { Hammer, Palette, Users } from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      icon: Hammer,
      title: "Custom Furniture",
      description: "Bespoke furniture pieces designed and crafted to your exact specifications and space requirements."
    },
    {
      icon: Palette,
      title: "Interior Styling",
      description: "Complete interior design services to create cohesive, stunning spaces that reflect your personality."
    },
    {
      icon: Users,
      title: "Design Consultation",
      description: "Expert guidance from our design team to help you make informed decisions about your furniture choices."
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-6">
            Our <span className="gradient-text">Services</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            From concept to creation, we provide comprehensive furniture solutions tailored to your unique vision.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={service.title}
                className="text-center group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                <motion.div
                  className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.3 }}
                >
                  <IconComponent className="text-2xl text-white" size={32} />
                </motion.div>
                <h3 className="text-2xl font-playfair font-semibold mb-4">
                  {service.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
