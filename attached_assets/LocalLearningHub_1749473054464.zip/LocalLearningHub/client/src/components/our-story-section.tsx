import { motion } from "framer-motion";

export default function OurStorySection() {
  return (
    <section id="our-story" className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Our Story
          </h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Blackhorse Furnitures is built on a foundation of authentic Indian craftsmanship, 
            where tradition meets contemporary design excellence.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              Crafting Dreams Since 2015
            </h3>
            <p className="text-gray-700 mb-6 leading-relaxed">
              Founded with a vision to preserve and elevate traditional Indian furniture craftsmanship, 
              Blackhorse Furnitures has become synonymous with luxury, quality, and authentic design. 
              Our journey began in the workshops of master artisans who have passed down their skills 
              through generations.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Today, we serve discerning clients across India, creating bespoke furniture pieces that 
              tell stories of heritage while embracing modern aesthetics. From luxury villas in 
              Hyderabad to coastal retreats in Goa, our creations transform spaces into sanctuaries 
              of elegance.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img 
              src="/attached_assets/img13.png" 
              alt="Luxury living room set by Blackhorse Furnitures"
              className="rounded-2xl shadow-2xl w-full h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
          </motion.div>
        </div>

        {/* Founders Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Amar Chauhan */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100"
          >
            <div className="flex items-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mr-6">
                AC
              </div>
              <div>
                <h4 className="text-2xl font-bold text-gray-900">Amar Chauhan</h4>
                <p className="text-amber-600 font-medium">Co-Founder & Master Craftsman</p>
              </div>
            </div>
            <p className="text-gray-700 leading-relaxed mb-4">
              With over 20 years of experience in traditional Indian woodworking, Amar brings 
              unparalleled expertise in furniture design and craftsmanship. His deep understanding 
              of wood grain, joinery techniques, and finishing processes ensures every piece meets 
              the highest standards of quality.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Amar's vision for Blackhorse Furnitures is to create timeless pieces that celebrate 
              India's rich heritage while serving the needs of contemporary living spaces.
            </p>
          </motion.div>

          {/* Diksha Shiring */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100"
          >
            <div className="flex items-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-rose-400 to-rose-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mr-6">
                DS
              </div>
              <div>
                <h4 className="text-2xl font-bold text-gray-900">Diksha Shiring</h4>
                <p className="text-rose-600 font-medium">Co-Founder & Design Director</p>
              </div>
            </div>
            <p className="text-gray-700 leading-relaxed mb-4">
              Diksha's background in interior design and passion for Indian aesthetics drives 
              the creative vision at Blackhorse Furnitures. She specializes in translating 
              client dreams into stunning furniture pieces that perfectly complement their 
              living spaces.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Her expertise in color theory, spatial design, and material selection has been 
              instrumental in creating signature collections that have transformed luxury 
              residences across India.
            </p>
          </motion.div>
        </div>

        {/* Company Values */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <h3 className="text-3xl font-bold text-gray-900 mb-12">Our Values</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🏛️</span>
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-3">Heritage</h4>
              <p className="text-gray-600">
                Preserving traditional Indian craftsmanship techniques passed down through generations.
              </p>
            </div>
            <div className="p-6">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">⭐</span>
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-3">Quality</h4>
              <p className="text-gray-600">
                Uncompromising attention to detail and use of premium materials in every creation.
              </p>
            </div>
            <div className="p-6">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🎨</span>
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-3">Innovation</h4>
              <p className="text-gray-600">
                Blending traditional techniques with contemporary design for modern living.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}