import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ChevronDown, Play } from "lucide-react";
import { useState, useEffect } from "react";

export default function HeroSection() {
  const [currentTagline, setCurrentTagline] = useState(0);
  
  const taglines = [
    "Furniture Woven with Heritage.",
    "Curated Spaces, Crafted Narratives.",
    "Where Texture Meets Precision.",
    "Contemporary Living. Rooted in Craftsmanship.",
    "Every Piece, a Story. Every Space, a Statement."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTagline((prev) => (prev + 1) % taglines.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Premium Background with Multiple Layers */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 parallax-bg"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1566665797739-1674de7a421a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-black/40 to-black/70"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute top-20 right-20 w-32 h-32 bg-gradient-to-br from-yellow-400/20 to-orange-600/20 rounded-full blur-xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-40 left-20 w-24 h-24 bg-gradient-to-br from-amber-400/20 to-yellow-600/20 rounded-full blur-xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.4, 0.7, 0.4]
          }}
          transition={{ duration: 6, repeat: Infinity }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-screen">
          {/* Content Section */}
          <motion.div
            className="text-center lg:text-left"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <motion.div
              className="mb-4"
              key={currentTagline}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.6 }}
            >
              <p className="text-yellow-400 text-lg font-medium tracking-wide">
                {taglines[currentTagline]}
              </p>
            </motion.div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-playfair font-bold text-white mb-6 leading-tight text-shadow-luxury">
              Timeless{" "}
              <span className="gradient-text bg-gradient-to-r from-yellow-400 to-amber-600 bg-clip-text text-transparent">
                Indian
              </span>
              <br />
              Furniture Excellence
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
              Minimalistic. Contemporary. Artistic.<br />
              <span className="text-yellow-400">Designed with purpose, built with precision.</span>
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start mb-8">
              <Button
                onClick={() => scrollToSection("collections")}
                className="blackhorse-gradient text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 group relative overflow-hidden"
              >
                <span className="relative z-10">Explore Studio</span>
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 to-amber-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
              
              <Button
                onClick={() => scrollToSection("contact")}
                variant="outline"
                className="border-2 border-yellow-400 text-yellow-400 px-8 py-4 rounded-full text-lg font-semibold hover:bg-yellow-400 hover:text-black transition-all duration-300 group"
              >
                <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                Request Consultation
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-gray-700">
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1 }}
              >
                <div className="text-2xl font-bold text-yellow-400">700+</div>
                <div className="text-sm text-gray-400">Projects</div>
              </motion.div>
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.2 }}
              >
                <div className="text-2xl font-bold text-yellow-400">5+</div>
                <div className="text-sm text-gray-400">Years</div>
              </motion.div>
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.4 }}
              >
                <div className="text-2xl font-bold text-yellow-400">200+</div>
                <div className="text-sm text-gray-400">Happy Clients</div>
              </motion.div>
            </div>
          </motion.div>

          {/* 3D Visual Section */}
          <motion.div
            className="relative perspective-1000"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
          >
            <div className="relative transform-3d">
              <motion.div
                className="relative z-10"
                animate={{ 
                  rotateY: [0, 5, 0, -5, 0],
                  rotateX: [0, 2, 0, -2, 0]
                }}
                transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
              >
                <img
                  src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                  alt="Luxury Indian furniture showcase"
                  className="w-full h-auto rounded-2xl shadow-2xl"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-2xl"></div>
              </motion.div>
              
              {/* Floating accent elements */}
              <motion.div
                className="absolute -top-8 -right-8 w-24 h-24 bg-yellow-400/20 rounded-full blur-xl"
                animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.8, 0.5] }}
                transition={{ duration: 4, repeat: Infinity }}
              />
              <motion.div
                className="absolute -bottom-6 -left-6 w-16 h-16 bg-amber-500/30 rounded-full blur-lg"
                animate={{ scale: [1.2, 1, 1.2], opacity: [0.4, 0.7, 0.4] }}
                transition={{ duration: 5, repeat: Infinity }}
              />
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-yellow-400"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="text-2xl animate-bounce" />
      </motion.div>
    </section>
  );
}
