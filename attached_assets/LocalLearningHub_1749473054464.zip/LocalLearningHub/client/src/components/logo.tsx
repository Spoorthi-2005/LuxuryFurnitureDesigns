export default function Logo({ className = "h-8 w-auto" }: { className?: string }) {
  return (
    <div className={`${className} flex items-center space-x-2`}>
      <div className="relative">
        <svg
          viewBox="0 0 60 60"
          className="h-full w-auto"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Horse silhouette */}
          <path
            d="M15 45 C12 42, 10 38, 12 35 C14 32, 18 30, 22 32 C24 28, 28 25, 32 27 C36 25, 40 28, 42 32 C46 30, 50 32, 52 35 C54 38, 52 42, 49 45 C47 48, 43 50, 38 48 C35 52, 30 52, 25 48 C20 50, 16 48, 15 45 Z"
            fill="currentColor"
            className="text-amber-600"
          />
          {/* Decorative elements */}
          <circle cx="20" cy="35" r="2" fill="currentColor" className="text-amber-800" />
          <circle cx="40" cy="35" r="2" fill="currentColor" className="text-amber-800" />
          <path
            d="M25 20 Q30 15, 35 20 Q32 25, 30 30 Q28 25, 25 20"
            fill="currentColor"
            className="text-amber-700"
          />
        </svg>
      </div>
      <div className="flex flex-col">
        <span className="text-lg font-bold text-gray-900 leading-tight">
          BLACKHORSE
        </span>
        <span className="text-xs text-amber-600 font-medium tracking-wider">
          FURNITURES
        </span>
      </div>
    </div>
  );
}