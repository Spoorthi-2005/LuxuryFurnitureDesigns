import { motion } from "framer-motion";

export default function CraftsmanshipSection() {
  const features = [
    {
      title: "Premium Materials",
      description: "Only the finest woods, fabrics, and hardware from trusted suppliers worldwide."
    },
    {
      title: "Artisan Craftsmanship",
      description: "Each piece is meticulously handcrafted by skilled artisans with decades of experience."
    },
    {
      title: "Quality Assurance",
      description: "Rigorous quality control ensures every piece meets our exacting standards."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            className="order-2 lg:order-1"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
              European Design,<br />
              <span className="gradient-text">Indian Soul</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Our master craftsmen combine time-honored Indian techniques with contemporary European design principles, 
              creating furniture that transcends cultural boundaries and stands the test of time.
            </p>

            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <div className="w-6 h-6 bg-yellow-600 rounded-full flex-shrink-0 mt-1"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">
                      {feature.title}
                    </h4>
                    <p className="text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            className="order-1 lg:order-2"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <img
              src="https://images.unsplash.com/photo-1503602642458-232111445657?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
              alt="Master craftsman working on luxury furniture"
              className="w-full h-auto rounded-2xl shadow-2xl"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
