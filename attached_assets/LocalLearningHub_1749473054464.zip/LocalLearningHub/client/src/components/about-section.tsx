import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export default function AboutSection() {
  const [projectsCount, setProjectsCount] = useState(0);
  const [craftsmenCount, setCraftsmenCount] = useState(0);

  useEffect(() => {
    const animateCounter = (target: number, setter: (value: number) => void) => {
      let current = 0;
      const increment = target / 100;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setter(Math.floor(current));
      }, 20);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateCounter(1000, setProjectsCount);
            animateCounter(50, setCraftsmenCount);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 }
    );

    const statsSection = document.getElementById("about");
    if (statsSection) {
      observer.observe(statsSection);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <img
              src="https://images.unsplash.com/photo-1503602642458-232111445657?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Furniture artisans at work in modern workshop"
              className="w-full h-auto rounded-2xl shadow-2xl"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
              Three Generations of <span className="gradient-text">Excellence</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Founded in 1985, Blackhorse Furnitures has been at the forefront of luxury furniture manufacturing, 
              combining traditional Indian craftsmanship with contemporary design aesthetics.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <motion.div
                className="text-center p-6 bg-stone-50 rounded-xl"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <div className="text-3xl font-bold text-yellow-600 mb-2">
                  {projectsCount}+
                </div>
                <div className="text-gray-600">Projects Completed</div>
              </motion.div>
              <motion.div
                className="text-center p-6 bg-stone-50 rounded-xl"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <div className="text-3xl font-bold text-yellow-600 mb-2">
                  {craftsmenCount}+
                </div>
                <div className="text-gray-600">Master Craftsmen</div>
              </motion.div>
            </div>

            <Button className="bg-yellow-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-yellow-700 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg">
              Learn Our Story
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
