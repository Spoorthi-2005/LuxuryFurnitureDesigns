import { motion } from "framer-motion";
import img17 from "@assets/img17.png";
import img18 from "@assets/img18.png";
import img19 from "@assets/img19.png";

interface PortfolioSectionProps {
  onImageClick: (image: { src: string; alt: string }) => void;
}

export default function PortfolioSection({ onImageClick }: PortfolioSectionProps) {
  const portfolioItems = [
    {
      id: 1,
      title: "Five-Star Hotel Lobby",
      location: "Mumbai",
      image: img17,
      alt: "Yellow velvet chairs with cane back design in luxury hotel lobby"
    },
    {
      id: 2,
      title: "Penthouse Residence",
      location: "Delhi",
      image: img18,
      alt: "Navy blue swivel chair with brass accent in modern residence"
    },
    {
      id: 3,
      title: "Corporate Headquarters",
      location: "Bangalore",
      image: img19,
      alt: "Gray upholstered swivel chair in corporate office setting"
    },
    {
      id: 4,
      title: "Fine Dining Restaurant",
      location: "Goa",
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      alt: "Boutique restaurant dining area with custom furniture"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-stone-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
            Project <span className="gradient-text">Portfolio</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our recent projects and see how we transform spaces with our exceptional furniture collections.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {portfolioItems.map((item, index) => (
            <motion.div
              key={item.id}
              className="group cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
            >
              <div className="aspect-square overflow-hidden rounded-xl">
                <img
                  src={item.image}
                  alt={item.alt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  onClick={() => onImageClick({ src: item.image, alt: item.alt })}
                />
              </div>
              <div className="mt-4">
                <h4 className="font-playfair font-semibold text-lg text-gray-900">
                  {item.title}
                </h4>
                <p className="text-gray-600">{item.location}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
