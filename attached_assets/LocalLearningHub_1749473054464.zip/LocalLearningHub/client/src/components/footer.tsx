import { Facebook, Instagram, Linkedin, Phone, Mail, MapPin, Clock } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  const footerLinks = {
    navigation: [
      { name: "Home", href: "/" },
      { name: "Our Story", href: "/our-story" },
      { name: "Collections", href: "/collections" },
      { name: "Projects", href: "/projects" },
      { name: "Reviews", href: "/reviews" },
      { name: "Blogs", href: "/blogs" },
      { name: "Contact", href: "/contact" }
    ],
    services: [
      "Custom Furniture Design",
      "Interior Consultation",
      "Project Management",
      "Installation & Setup"
    ]
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Company Info */}
          <div className="col-span-1 lg:col-span-1">
            <h3 className="text-2xl font-bold mb-6">Blackhorse Furnitures</h3>
            <p className="text-gray-300 leading-relaxed mb-6">
              Crafting exquisite furniture with traditional Indian artistry and contemporary design. 
              Your vision, our craftsmanship - creating timeless pieces for elegant living spaces.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="w-10 h-10 bg-amber-600 rounded-full flex items-center justify-center hover:bg-amber-700 transition-colors"
              >
                <Facebook size={18} />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-amber-600 rounded-full flex items-center justify-center hover:bg-amber-700 transition-colors"
              >
                <Instagram size={18} />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-amber-600 rounded-full flex items-center justify-center hover:bg-amber-700 transition-colors"
              >
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {footerLinks.navigation.map((item) => (
                <li key={item.name}>
                  <Link href={item.href} className="text-gray-300 hover:text-amber-400 transition-colors">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Our Services</h4>
            <ul className="space-y-3">
              {footerLinks.services.map((item) => (
                <li key={item}>
                  <span className="text-gray-300">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin size={18} className="text-amber-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300 text-sm">
                    351, Khari Estate<br />
                    Sultanpur MG Road<br />
                    New Delhi - 110030
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Phone size={18} className="text-amber-400 flex-shrink-0" />
                <div className="text-sm">
                  <a href="tel:+919718978337" className="text-gray-300 hover:text-amber-400 transition-colors block">
                    +91 97189 78337 (Amar)
                  </a>
                  <a href="tel:+918826560644" className="text-gray-300 hover:text-amber-400 transition-colors block">
                    +91 88265 60644 (Diksha)
                  </a>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Mail size={18} className="text-amber-400 flex-shrink-0" />
                <div className="text-sm">
                  <a href="mailto:amarchauhan1287@gmail.com" className="text-gray-300 hover:text-amber-400 transition-colors block">
                    amarchauhan1287@gmail.com
                  </a>
                  <a href="mailto:dikshas2591@gmail.com" className="text-gray-300 hover:text-amber-400 transition-colors block">
                    dikshas2591@gmail.com
                  </a>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Clock size={18} className="text-amber-400 mt-1 flex-shrink-0" />
                <div className="text-gray-300 text-sm">
                  Mon-Sat: 9AM-7PM<br />
                  Sunday: 10AM-5PM
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Blackhorse Furnitures. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-amber-400 transition-colors text-sm">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
