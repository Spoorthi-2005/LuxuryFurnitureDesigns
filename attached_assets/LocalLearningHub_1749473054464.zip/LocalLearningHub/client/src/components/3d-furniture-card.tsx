import { useState } from "react";
import { motion } from "framer-motion";

interface FurnitureCardProps {
  image: string;
  title: string;
  description: string;
  price: string;
  category: string;
}

export default function FurnitureCard3D({ image, title, description, price, category }: FurnitureCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      className="relative group cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
    >
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
        <div className="relative h-80 overflow-hidden">
          <motion.img
            src={`/attached_assets/${image}`}
            alt={title}
            className="w-full h-full object-cover"
            animate={{
              rotateY: isHovered ? 15 : 0,
              scale: isHovered ? 1.1 : 1,
            }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            style={{
              transformStyle: "preserve-3d",
              filter: isHovered ? "brightness(1.1)" : "brightness(1)",
            }}
          />
          
          {/* 3D Shadow Effect */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-black/20"
            animate={{
              opacity: isHovered ? 1 : 0,
            }}
            transition={{ duration: 0.3 }}
          />
          
          {/* Category Badge */}
          <div className="absolute top-4 left-4">
            <span className="bg-amber-600 text-white text-xs font-medium px-3 py-1 rounded-full">
              {category}
            </span>
          </div>
          
          {/* Hover Overlay */}
          <motion.div
            className="absolute inset-0 bg-black/40 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 1 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.button
              className="bg-white text-gray-900 px-6 py-2 rounded-full font-medium transform"
              initial={{ y: 20 }}
              animate={{ y: isHovered ? 0 : 20 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              View Details
            </motion.button>
          </motion.div>
        </div>
        
        <div className="p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 text-sm mb-4">{description}</p>
          <div className="flex justify-between items-center">
            <span className="text-2xl font-bold text-amber-600">{price}</span>
            <button className="text-amber-600 hover:text-amber-700 font-medium text-sm">
              Learn More →
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}