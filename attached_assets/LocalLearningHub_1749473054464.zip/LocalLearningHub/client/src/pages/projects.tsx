import { motion } from "framer-motion";
import { useState } from "react";
import { Calendar, MapPin, Users, Clock } from "lucide-react";

export default function Projects() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const projects = [
    {
      id: 1,
      title: "Luxury Villa Interior - Hyderabad",
      location: "Hyderabad, Telangana",
      category: "Residential",
      duration: "3 months",
      budget: "₹25,00,000",
      description: "Complete furniture solution for a 5000 sq ft luxury villa featuring handcrafted living room sets, premium dining furniture, and custom bedroom collections with traditional Indian motifs. This project showcases our expertise in blending Deccan heritage with contemporary luxury.",
      images: ["img8.png", "img13.png", "img24.png", "img7.png", "img12.png", "img26.png", "img27.png", "img35.png"],
      completedAt: "March 2024",
      featured: true
    },
    {
      id: 2,
      title: "Coastal Villa Furnishing - Goa",
      location: "Goa",
      category: "Residential",
      duration: "2 months",
      budget: "₹18,00,000",
      description: "Sophisticated casual furniture collection for a beachside villa, combining comfort with elegant Indian design elements. Features weather-resistant materials and coastal-inspired aesthetics that capture the essence of Portuguese-Indian architecture.",
      images: ["img17.png", "img19.png", "img22.png", "img18.png", "img14.png", "img31.png", "img36.png"],
      completedAt: "May 2024",
      featured: true
    },
    {
      id: 3,
      title: "Heritage Mansion - Delhi",
      location: "New Delhi",
      category: "Heritage",
      duration: "4 months",
      budget: "₹35,00,000",
      description: "Restoration and furnishing of a heritage mansion with period-accurate furniture pieces, incorporating traditional Indian craftsmanship with modern functionality. Each piece tells the story of Delhi's rich Mughal and British colonial heritage.",
      images: ["img9.png", "img23.png", "img8.png", "img13.png", "img17.png", "img25.png", "img28.png"],
      completedAt: "January 2024",
      featured: true
    },
    {
      id: 4,
      title: "Modern Penthouse - Mumbai",
      location: "Mumbai, Maharashtra",
      category: "Contemporary",
      duration: "2.5 months",
      budget: "₹28,00,000",
      description: "Contemporary furniture design for a luxury penthouse, blending modern aesthetics with Indian artistic elements. Features custom-made pieces and imported materials that reflect Mumbai's cosmopolitan spirit.",
      images: ["img18.png", "img19.png", "img22.png", "img7.png", "img14.png", "img29.png", "img30.png"],
      completedAt: "August 2024",
      featured: false
    },
    {
      id: 5,
      title: "Boutique Hotel Suite - Rajasthan",
      location: "Jaipur, Rajasthan",
      category: "Hospitality",
      duration: "5 months",
      budget: "₹45,00,000",
      description: "Luxury hotel suite project featuring 20 rooms with bespoke furniture that celebrates Rajasthani royal heritage. Each room tells a different story through carefully curated pieces that blend palatial grandeur with modern comfort.",
      images: ["img26.png", "img27.png", "img28.png", "img29.png", "img25.png", "img31.png"],
      completedAt: "September 2024",
      featured: true
    },
    {
      id: 6,
      title: "Corporate Office - Bangalore",
      location: "Bangalore, Karnataka",
      category: "Commercial",
      duration: "4 months",
      budget: "₹32,00,000",
      description: "Modern corporate office furniture design that reflects India's tech innovation spirit. Custom workstations and meeting rooms furnished with pieces that inspire creativity while honoring traditional craftsmanship values.",
      images: ["img35.png", "img36.png", "img30.png", "img31.png", "img14.png"],
      completedAt: "November 2024",
      featured: false
    }
  ];

  const categories = ["all", "Residential", "Heritage", "Contemporary", "Hospitality", "Commercial"];

  const filteredProjects = selectedCategory === "all" 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-amber-50 pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Our <span className="text-amber-600">Projects</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Explore our portfolio of 700+ completed projects, showcasing exceptional 
            Indian furniture craftsmanship in luxury villas and prestigious residences.
          </p>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          <div className="text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">700+</div>
            <div className="text-gray-600">Projects Completed</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">50+</div>
            <div className="text-gray-600">Cities Served</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">98%</div>
            <div className="text-gray-600">Client Satisfaction</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">30+</div>
            <div className="text-gray-600">Years Experience</div>
          </div>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex justify-center mb-12"
        >
          <div className="bg-white rounded-full p-2 shadow-lg">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  selectedCategory === category
                    ? "bg-amber-600 text-white"
                    : "text-gray-600 hover:text-amber-600"
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid lg:grid-cols-2 gap-12">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="bg-white rounded-3xl shadow-xl overflow-hidden group hover:shadow-2xl transition-all duration-500"
            >
              {/* Project Images */}
              <div className="relative h-80 overflow-hidden">
                <div className="grid grid-cols-3 h-full gap-1">
                  {project.images.slice(0, 3).map((image, imgIndex) => (
                    <motion.img
                      key={imgIndex}
                      src={`/attached_assets/${image}`}
                      alt={`${project.title} - Image ${imgIndex + 1}`}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      whileHover={{ 
                        rotateY: 10,
                        scale: 1.05 
                      }}
                      transition={{ duration: 0.5 }}
                    />
                  ))}
                </div>
                
                {project.featured && (
                  <div className="absolute top-4 left-4">
                    <span className="bg-amber-600 text-white text-xs font-medium px-3 py-1 rounded-full">
                      Featured Project
                    </span>
                  </div>
                )}
              </div>

              {/* Project Details */}
              <div className="p-8">
                <div className="flex items-center gap-2 mb-2">
                  <MapPin size={16} className="text-amber-600" />
                  <span className="text-sm text-gray-600">{project.location}</span>
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-3">{project.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-6">{project.description}</p>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="flex items-center gap-2">
                    <Clock size={16} className="text-amber-600" />
                    <span className="text-sm text-gray-600">{project.duration}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={16} className="text-amber-600" />
                    <span className="text-sm text-gray-600">{project.completedAt}</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-amber-600">{project.budget}</span>
                  <button className="bg-amber-600 text-white px-6 py-2 rounded-full hover:bg-amber-700 transition-colors duration-300">
                    View Details
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-20 bg-gradient-to-r from-amber-600 to-amber-700 rounded-3xl p-12 text-center text-white"
        >
          <h2 className="text-4xl font-bold mb-4">Ready to Start Your Project?</h2>
          <p className="text-xl mb-8 opacity-90">
            Let us transform your space with our exquisite Indian furniture collections
          </p>
          <button className="bg-white text-amber-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors duration-300">
            Get Free Consultation
          </button>
        </motion.div>

      </div>
    </div>
  );
}