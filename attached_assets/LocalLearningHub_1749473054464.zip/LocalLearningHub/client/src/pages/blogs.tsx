import { motion } from "framer-motion";
import { useState } from "react";
import { Calendar, User, ArrowRight, Tag } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Blogs() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: blogs = [], isLoading } = useQuery({
    queryKey: ["/api/blogs/published"],
  });

  const categories = ["all", "Craftsmanship", "Projects", "Design Tips", "Trends"];

  const filteredBlogs = selectedCategory === "all" 
    ? blogs 
    : blogs.filter((blog: any) => blog.category === selectedCategory);

  const featuredBlog = blogs.find((blog: any) => blog.id === 1);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-amber-50 pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Design <span className="text-amber-600">Insights</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Explore the world of Indian furniture craftsmanship, design trends, and expert insights 
            from our team at Blackhorse Furnitures.
          </p>
        </motion.div>

        {/* Featured Blog */}
        {featuredBlog && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-white rounded-3xl shadow-xl overflow-hidden mb-16"
          >
            <div className="grid lg:grid-cols-2 gap-0">
              <div className="relative h-80 lg:h-auto">
                <img
                  src="/attached_assets/img8.png"
                  alt={featuredBlog.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-6 left-6">
                  <span className="bg-amber-600 text-white text-sm font-medium px-4 py-2 rounded-full">
                    Featured Article
                  </span>
                </div>
              </div>
              <div className="p-12 flex flex-col justify-center">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1 text-gray-500">
                    <Tag size={16} />
                    <span className="text-sm">{featuredBlog.category}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-500">
                    <Calendar size={16} />
                    <span className="text-sm">{new Date(featuredBlog.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">{featuredBlog.title}</h2>
                <p className="text-gray-600 leading-relaxed mb-6">{featuredBlog.excerpt}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User size={16} className="text-amber-600" />
                    <span className="text-sm text-gray-600">By {featuredBlog.author}</span>
                  </div>
                  <button className="flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium">
                    Read Article <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex justify-center mb-12"
        >
          <div className="bg-white rounded-full p-2 shadow-lg">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  selectedCategory === category
                    ? "bg-amber-600 text-white"
                    : "text-gray-600 hover:text-amber-600"
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Blog Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden shadow-lg animate-pulse">
                <div className="h-48 bg-gray-200"></div>
                <div className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-20 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredBlogs.slice(1).map((blog: any, index: number) => (
              <motion.article
                key={blog.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 group"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={`/attached_assets/img${Math.floor(Math.random() * 20) + 7}.png`}
                    alt={blog.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-white/90 text-amber-600 text-xs font-medium px-3 py-1 rounded-full">
                      {blog.category}
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center gap-4 mb-3 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar size={14} />
                      <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User size={14} />
                      <span>{blog.author}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                    {blog.title}
                  </h3>
                  
                  <p className="text-gray-600 leading-relaxed mb-4 line-clamp-3">
                    {blog.excerpt}
                  </p>
                  
                  <button className="flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium group">
                    Read More 
                    <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </motion.article>
            ))}
          </motion.div>
        )}

        {/* Newsletter Signup */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-20 bg-gradient-to-r from-amber-600 to-amber-700 rounded-3xl p-12 text-center text-white"
        >
          <h2 className="text-4xl font-bold mb-4">Stay Updated</h2>
          <p className="text-xl mb-8 opacity-90">
            Subscribe to our newsletter for the latest design insights and furniture trends
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-6 py-3 rounded-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
            />
            <button className="bg-white text-amber-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors duration-300">
              Subscribe
            </button>
          </div>
        </motion.div>

      </div>
    </div>
  );
}