import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import FurnitureCard3D from "@/components/3d-furniture-card";

export default function Collections() {
  const [activeTab, setActiveTab] = useState("living");

  const collections = {
    living: [
      {
        id: 1,
        title: "Royal Heritage Sofa Set",
        description: "Inspired by Rajasthani palaces, this majestic sofa set tells the story of ancient Indian royalty. Handcrafted by master artisans using 300-year-old techniques, featuring premium silk upholstery woven with golden threads that shimmer like desert sands at sunset.",
        image: "img8.png",
        alt: "Luxury living room setup with beige sofas",
        category: "Living Room"
      },
      {
        id: 2,
        title: "Premium Leather Armchairs",
        description: "Born from the legacy of Mughal craftsmanship, these armchairs embody the elegance of emperors. Each piece is hand-stitched with leather treated using traditional Indian methods, while brass fittings are forged by hereditary metalworkers from Moradabad.",
        image: "img7.png",
        alt: "Cream leather armchairs with brass details",
        category: "Living Room"
      },
      {
        id: 3,
        title: "Contemporary Sectional",
        description: "A modern interpretation of traditional Indian gathering spaces where families shared stories. The quilted pattern echoes the intricate designs of Kashmiri shawls, while brass trim pays homage to temple architecture.",
        image: "img9.png",
        alt: "Pink quilted sectional sofa",
        category: "Living Room"
      },
      {
        id: 4,
        title: "Classic Chesterfield Set",
        description: "This timeless design marries British colonial elegance with Indian sensibilities. Button-tufted by hand using techniques passed down through generations of upholsterers in Chennai, creating furniture that bridges two cultures.",
        image: "img13.png",
        alt: "White tufted sofa set with wooden tables",
        category: "Living Room"
      },
      {
        id: 5,
        title: "Modern Swivel Chair",
        description: "Inspired by the rotating chaukis of ancient Indian courts, this contemporary piece allows for dynamic conversation. The navy velvet recalls the deep blue of midnight ragas, while the brass base gleams like temple bells.",
        image: "img18.png",
        alt: "Blue velvet swivel chair",
        category: "Living Room"
      },
      {
        id: 6,
        title: "Contemporary Cream Lounge Chairs",
        description: "These sculptural chairs tell the story of modern Indian design evolution. Inspired by the flowing forms of Bharatanatyam dancers, each curve represents graceful movement frozen in time. The cream upholstery symbolizes purity and new beginnings.",
        image: "img35.png",
        alt: "Contemporary cream lounge chairs with geometric rug",
        category: "Living Room"
      },
      {
        id: 7,
        title: "Artistic Statement Chairs",
        description: "Beneath the golden artwork that speaks of dreams and aspirations, these chairs embody the fusion of art and functionality. White upholstery represents canvas, while dark wooden frames ground the design in earthy Indian aesthetics.",
        image: "img36.png",
        alt: "White chairs with dark wooden frames under artistic wall",
        category: "Living Room"
      },
      {
        id: 8,
        title: "Vintage Cane Chairs",
        description: "These heritage pieces carry the soul of rural India into modern homes. Each cane strand is woven by village artisans whose families have practiced this craft for centuries, creating furniture that breathes with the rhythm of nature.",
        image: "img17.png",
        alt: "Yellow vintage chairs with cane backing",
        category: "Living Room"
      },
      {
        id: 9,
        title: "Comfort Recliner",
        description: "Designed for contemplation and rest, this recliner embodies the Indian philosophy of balance. Its ergonomic form supports the body like a gentle embrace, while the gray fabric evokes the calming monsoon clouds.",
        image: "img19.png",
        alt: "Gray comfortable recliner",
        category: "Living Room"
      },
      {
        id: 10,
        title: "Designer Coffee Table",
        description: "This brass coffee table tells the story of Indian metalworking heritage. Each geometric pattern is hand-etched by craftsmen from Jaipur, creating surfaces that catch and reflect light like precious jewelry.",
        image: "img14.png",
        alt: "Brass coffee table with decorative elements",
        category: "Living Room"
      }
    ],
    dining: [
      {
        id: 11,
        title: "Heritage Dining Set",
        description: "These quilted dining chairs echo the grandeur of Maharaja dining halls. Each brass chain detail is hand-forged by artisans from Rajasthan, while the walnut wood carries the warm essence of Indian forests where elephants once roamed.",
        image: "img12.png",
        alt: "Quilted dining chairs with black legs",
        category: "Dining Room"
      },
      {
        id: 12,
        title: "Designer Glass Table",
        description: "This contemporary masterpiece tells the story of transparency and connection. The marble base is carved from stones quarried in Rajasthan, each vein telling millions of years of geological history, supporting gatherings that create new memories.",
        image: "img23.png",
        alt: "Quilted dining chairs with marble table",
        category: "Dining Room"
      },
      {
        id: 13,
        title: "Luxury Dining Chairs",
        description: "Wrapped in cream leather that speaks of pastoral abundance, these chairs embody the hospitality tradition of Indian culture. Each stitch is placed with the reverence of temple craftsmen, creating seating worthy of honored guests.",
        image: "img22.png",
        alt: "Cream leather dining chair",
        category: "Dining Room"
      },
      {
        id: 14,
        title: "Grand Dining Suite",
        description: "This expansive dining setup recreates the communal spirit of Indian joint families. The glass table reflects not just light but the warmth of shared meals, while upholstered seating embraces every guest like family.",
        image: "img24.png",
        alt: "Elegant dining setup with glass table",
        category: "Dining Room"
      },
      {
        id: 15,
        title: "Elegant Sideboard Console",
        description: "This magnificent sideboard tells the tale of royal storage traditions. The gray fluted pattern mimics the architectural columns of ancient Indian temples, while brass accents gleam like ceremonial vessels used in palace banquets.",
        image: "img25.png",
        alt: "Gray fluted sideboard with brass trim",
        category: "Dining Room"
      },
      {
        id: 16,
        title: "Cane Door Storage Cabinet",
        description: "Inspired by the cooling cabinets of colonial bungalows, this piece marries functionality with heritage. The intricate cane work allows air circulation while creating beautiful shadow patterns that dance across stored treasures.",
        image: "img31.png",
        alt: "White cabinet with cane door panels",
        category: "Dining Room"
      },
      {
        id: 17,
        title: "Contemporary Display Unit",
        description: "This sleek display piece tells the story of modern Indian entertaining. Clean lines reflect contemporary aesthetics while maintaining the soul of traditional hospitality, perfect for showcasing precious dinnerware and family heirlooms.",
        image: "img30.png",
        alt: "Modern white display cabinet with brass details",
        category: "Dining Room"
      },
      {
        id: 18,
        title: "Art Deco Side Table",
        description: "This brass-finished cylindrical marvel celebrates the golden age of Indian craftsmanship. Each decorative element is hand-etched by master metalworkers whose techniques have been refined across generations, creating functional art.",
        image: "img14.png",
        alt: "Brass side table with decorative vase",
        category: "Dining Room"
      }
    ],
    bedroom: [
      {
        id: 19,
        title: "Majestic Geometric Headboard Bed",
        description: "This stunning bedroom ensemble tells the story of contemporary Indian luxury. The geometric quilted headboard draws inspiration from traditional Indian textile patterns, reimagined for modern royalty. Each diamond pattern represents the facets of a precious gem, creating a sanctuary of dreams.",
        image: "img26.png",
        alt: "Luxury bedroom with geometric quilted headboard",
        category: "Bedroom"
      },
      {
        id: 20,
        title: "Quilted Elegance Bed Frame",
        description: "Inspired by the intricate quilting traditions of Punjab, this bed frame celebrates the artistry of Indian textile heritage. The diamond-quilted pattern speaks of warmth and comfort, while brass accents echo the golden harvest fields of northern India.",
        image: "img27.png",
        alt: "Elegant quilted bed with brass trim",
        category: "Bedroom"
      },
      {
        id: 21,
        title: "Contemporary Textured Bed Suite",
        description: "This modern masterpiece weaves together the textures of Indian architecture. The 3D headboard mimics the carved stone facades of ancient temples, while the neutral palette creates a serene retreat reminiscent of mountain meditation caves.",
        image: "img28.png",
        alt: "Modern bed with textured headboard and matching nightstands",
        category: "Bedroom"
      },
      {
        id: 22,
        title: "Fluted Brass Nightstand",
        description: "This exquisite nightstand tells the tale of architectural grandeur. Each fluted groove echoes the columns of Jain temples, while brass hardware gleams like ceremonial temple vessels. The copper accents celebrate India's ancient metalworking traditions.",
        image: "img29.png",
        alt: "Luxury nightstand with fluted design and brass base",
        category: "Bedroom"
      },
      {
        id: 23,
        title: "Modern Storage Console",
        description: "This sleek bedside console embodies the evolution of Indian design philosophy. Clean lines merge with warm brass touches, creating furniture that honors tradition while embracing the future. Each drawer holds the promise of organized luxury.",
        image: "img30.png",
        alt: "Contemporary bedroom storage unit with brass details",
        category: "Bedroom"
      },
      {
        id: 24,
        title: "Royal Bed Frame",
        description: "Majestic king-size bed that channels the grandeur of ancient Indian palaces. Handcrafted with traditional joinery techniques passed down through royal furniture makers, each detail whispers stories of maharajas and their opulent chambers.",
        image: "img13.png",
        alt: "Elegant bedroom setup",
        category: "Bedroom"
      },
      {
        id: 25,
        title: "Luxury Nightstands",
        description: "These matching bedside companions carry the legacy of palace furniture. Brass handles are forged using traditional techniques from Moradabad, while marble tops are sourced from the same quarries that built the Taj Mahal.",
        image: "img14.png",
        alt: "Designer nightstand with brass details",
        category: "Bedroom"
      },
      {
        id: 26,
        title: "Comfort Reading Chair",
        description: "This peaceful reading sanctuary embodies the Indian tradition of contemplative spaces. Soft gray upholstery evokes monsoon clouds, while the swivel base allows for meditation in any direction, following the sun's path across the sky.",
        image: "img19.png",
        alt: "Gray fabric swivel chair",
        category: "Bedroom"
      },
      {
        id: 27,
        title: "Designer Wardrobe",
        description: "This custom wardrobe tells the story of modern Indian storage solutions. Mirrored doors reflect not just images but aspirations, while interior LED lighting creates an ethereal glow reminiscent of palace treasure chambers.",
        image: "img8.png",
        alt: "Luxury bedroom furniture",
        category: "Bedroom"
      },
      {
        id: 28,
        title: "Heritage Vanity Set",
        description: "This elegant dressing station celebrates the ritual of preparation and self-care. The illuminated mirror captures and enhances natural beauty, while storage drawers protect precious jewelry and cosmetics like a modern-day treasure chest.",
        image: "img22.png",
        alt: "Designer furniture setup",
        category: "Bedroom"
      }
    ],
    casual: [
      {
        id: 29,
        title: "Heritage Cane Chairs",
        description: "These timeless chairs carry the spirit of colonial India into contemporary homes. Each cane strand is hand-woven by artisans whose ancestors created furniture for British officers, now reimagined with mustard velvet that glows like marigold petals in temple courtyards.",
        image: "img17.png",
        alt: "Yellow vintage chairs with cane backing",
        category: "Casual Seating"
      },
      {
        id: 30,
        title: "Navy Velvet Swivel Ottoman",
        description: "This contemporary ottoman tells the story of modern Indian comfort. The deep navy velvet evokes the profound blue of Krishna's robes, while the brass accent band gleams like the sacred threads worn by devotees, creating furniture that nurtures both body and soul.",
        image: "img18.png",
        alt: "Blue round swivel chair",
        category: "Casual Seating"
      },
      {
        id: 31,
        title: "Meditation Recliner",
        description: "Designed for the Indian art of contemplative rest, this recliner embodies the balance between activity and repose. Its gray fabric mirrors the peaceful ash worn by sages, while ergonomic curves support the body's natural rhythm of breathing and reflection.",
        image: "img19.png",
        alt: "Gray comfortable recliner",
        category: "Casual Seating"
      },
      {
        id: 32,
        title: "Geometric Brass Coffee Table",
        description: "This artistic centerpiece celebrates India's mathematical heritage. Each geometric pattern references ancient Sanskrit texts on sacred geometry, while the brass finish reflects the golden ratio found in temple architecture, making every coffee ritual a meditative experience.",
        image: "img14.png",
        alt: "Brass coffee table with decorative elements",
        category: "Casual Seating"
      },
      {
        id: 33,
        title: "Contemporary Cream Lounge Suite",
        description: "These sculptural pieces reinterpret the flowing grace of classical Indian dance. Each curve captures the elegant hand gestures of Bharatanatyam, while cream upholstery represents the pure consciousness that emerges through artistic expression and mindful gathering.",
        image: "img35.png",
        alt: "Contemporary cream lounge chairs with geometric rug",
        category: "Casual Seating"
      },
      {
        id: 34,
        title: "Statement Art Seating",
        description: "Beneath artwork that speaks of golden dreams and human aspiration, these chairs create a dialogue between art and functionality. White frames symbolize blank canvas potential, while dark wood grounds the design in India's rich earth, fostering creative conversations.",
        image: "img36.png",
        alt: "White chairs with dark wooden frames under artistic wall",
        category: "Casual Seating"
      },
      {
        id: 35,
        title: "Modular Sectional",
        description: "This flexible seating arrangement embodies the Indian joint family system. Pink upholstery celebrates the joy of Holi festival, while modular design allows for infinite configurations, adapting to life's changing needs like the flowing verses of ancient epics.",
        image: "img9.png",
        alt: "Modular pink sectional seating",
        category: "Casual Seating"
      }
    ]
  };

  const tabs = [
    { key: "living", label: "Living Room", count: collections.living.length },
    { key: "dining", label: "Dining Room", count: collections.dining.length },
    { key: "bedroom", label: "Bedroom", count: collections.bedroom.length },
    { key: "casual", label: "Casual Seating", count: collections.casual.length },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 to-amber-50 pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Our <span className="text-amber-600">Collections</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover our exquisite range of handcrafted Indian furniture, where traditional 
            artistry meets contemporary design for the modern home.
          </p>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex justify-center mb-16"
        >
          <div className="bg-white rounded-2xl p-2 shadow-xl border border-gray-100">
            <div className="flex flex-wrap gap-2">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 flex items-center gap-2 ${
                    activeTab === tab.key
                      ? "bg-amber-600 text-white shadow-lg"
                      : "text-gray-600 hover:text-amber-600 hover:bg-amber-50"
                  }`}
                >
                  {tab.label}
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    activeTab === tab.key 
                      ? "bg-white/20 text-white" 
                      : "bg-gray-200 text-gray-600"
                  }`}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Collections Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.6 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {collections[activeTab as keyof typeof collections].map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <FurnitureCard3D
                  image={item.image}
                  title={item.title}
                  description={item.description}
                  price="Custom Quote"
                  category={item.category}
                />
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Custom Design CTA */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-20 bg-gradient-to-r from-amber-600 to-amber-700 rounded-3xl p-12 text-center text-white"
        >
          <h2 className="text-4xl font-bold mb-4">Need Something Custom?</h2>
          <p className="text-xl mb-8 opacity-90">
            Our master craftsmen can create bespoke furniture pieces tailored to your exact specifications
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-amber-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors duration-300">
              Request Custom Design
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-amber-600 transition-colors duration-300">
              Schedule Consultation
            </button>
          </div>
        </motion.div>

      </div>
    </div>
  );
}