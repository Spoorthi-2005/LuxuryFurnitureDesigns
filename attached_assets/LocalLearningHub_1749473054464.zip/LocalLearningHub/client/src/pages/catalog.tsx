import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { motion } from "framer-motion";
import { Download, Eye, Filter, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import img7 from "@assets/img7.png";
import img8 from "@assets/img8.png";
import img9 from "@assets/img9.png";
import img12 from "@assets/img12.png";
import img13 from "@assets/img13.png";
import img14 from "@assets/img14.png";
import img17 from "@assets/img17.png";
import img18 from "@assets/img18.png";
import img19 from "@assets/img19.png";

export default function Catalog() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedRoom, setSelectedRoom] = useState("all");

  const catalogItems = [
    {
      id: 1,
      name: "Royal Comfort Dining Chairs",
      category: "seating",
      room: "dining",
      description: "Premium quilted upholstery with gold-finished accents",
      price: "₹85,000 - ₹1,25,000",
      image: img12,
      specifications: ["High-density foam", "Premium fabrics", "Gold accents", "European standards"],
      dimensions: "W: 65cm, D: 70cm, H: 85cm"
    },
    {
      id: 2,
      name: "Metropolitan Sectional Collection",
      category: "sofa",
      room: "living",
      description: "Contemporary sectional sofas with clean lines and modern aesthetics",
      price: "₹1,25,000 - ₹2,50,000",
      image: img13,
      specifications: ["Modular design", "Contemporary styling", "Durable frames", "Custom configurations"],
      dimensions: "W: 280cm, D: 180cm, H: 85cm"
    },
    {
      id: 3,
      name: "Heritage Classic Armchairs",
      category: "seating",
      room: "living",
      description: "Timeless pieces with rich upholstery and traditional craftsmanship",
      price: "₹65,000 - ₹95,000",
      image: img14,
      specifications: ["Traditional craft", "Rich upholstery", "Timeless design", "Handcrafted details"],
      dimensions: "W: 75cm, D: 80cm, H: 90cm"
    },
    {
      id: 4,
      name: "Executive Lounge Chairs",
      category: "seating",
      room: "office",
      description: "Professional furniture with brass accents and premium leather",
      price: "₹45,000 - ₹75,000",
      image: img7,
      specifications: ["Brass accents", "Premium leather", "Ergonomic design", "Professional grade"],
      dimensions: "W: 70cm, D: 75cm, H: 85cm"
    },
    {
      id: 5,
      name: "Contemporary Living Set",
      category: "sofa",
      room: "living",
      description: "Modern sectional designs with high-quality fabrics",
      price: "₹95,000 - ₹1,85,000",
      image: img8,
      specifications: ["Sectional design", "Quality fabrics", "Modern styling", "Comfortable seating"],
      dimensions: "L-Shape: W: 250cm, D: 200cm, H: 80cm"
    },
    {
      id: 6,
      name: "Luxury Pink Velvet Sectional",
      category: "sofa",
      room: "living",
      description: "Pink velvet luxury sectionals with quilted detailing",
      price: "₹1,85,000 - ₹2,75,000",
      image: img9,
      specifications: ["Velvet upholstery", "Quilted details", "Luxury comfort", "Statement pieces"],
      dimensions: "U-Shape: W: 320cm, D: 220cm, H: 82cm"
    },
    {
      id: 7,
      name: "Hotel Collection Chairs",
      category: "seating",
      room: "commercial",
      description: "Yellow velvet chairs with cane back design for luxury spaces",
      price: "₹55,000 - ₹85,000",
      image: img17,
      specifications: ["Velvet upholstery", "Cane back detail", "Commercial grade", "Luxury finish"],
      dimensions: "W: 65cm, D: 70cm, H: 88cm"
    },
    {
      id: 8,
      name: "Navy Swivel Chair",
      category: "seating",
      room: "study",
      description: "Navy blue swivel chair with brass accent for modern residences",
      price: "₹35,000 - ₹55,000",
      image: img18,
      specifications: ["Swivel mechanism", "Brass accents", "Navy blue fabric", "Modern design"],
      dimensions: "W: 68cm, D: 68cm, H: 82cm"
    },
    {
      id: 9,
      name: "Corporate Swivel Chair",
      category: "seating",
      room: "office",
      description: "Gray upholstered swivel chair for corporate environments",
      price: "₹28,000 - ₹45,000",
      image: img19,
      specifications: ["Ergonomic design", "Swivel base", "Gray upholstery", "Corporate grade"],
      dimensions: "W: 65cm, D: 65cm, H: 85cm"
    }
  ];

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "sofa", label: "Sofas & Sectionals" },
    { value: "seating", label: "Chairs & Seating" },
    { value: "tables", label: "Tables" },
    { value: "storage", label: "Storage" }
  ];

  const rooms = [
    { value: "all", label: "All Rooms" },
    { value: "living", label: "Living Room" },
    { value: "dining", label: "Dining Room" },
    { value: "bedroom", label: "Bedroom" },
    { value: "office", label: "Office" },
    { value: "commercial", label: "Commercial" },
    { value: "study", label: "Study" }
  ];

  const filteredItems = catalogItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    const matchesRoom = selectedRoom === "all" || item.room === selectedRoom;
    
    return matchesSearch && matchesCategory && matchesRoom;
  });

  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-stone-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-6xl font-playfair font-bold text-gray-900 mb-6">
              E-<span className="gradient-text">Catalogs</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
              Discover our curated range of premium furniture, furnishings, and interior solutions — all in one place. 
              Our e-catalogs offer a seamless way to explore our collections, from custom furniture and modular 
              solutions to complete interior packages.
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
              Browse. Select. Get Inspired. Designed for homes, offices, hotels, and retail spaces.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <Input
                  type="text"
                  placeholder="Search furniture..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full sm:w-80"
                />
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedRoom} onValueChange={setSelectedRoom}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Room" />
                </SelectTrigger>
                <SelectContent>
                  {rooms.map((room) => (
                    <SelectItem key={room.value} value={room.value}>
                      {room.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              Showing {filteredItems.length} of {catalogItems.length} items
            </div>
          </div>
        </div>
      </section>

      {/* Catalog Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                className="furniture-card rounded-2xl overflow-hidden group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 flex gap-2">
                    <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-all">
                      <Eye size={16} />
                    </button>
                    <button className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-all">
                      <Download size={16} />
                    </button>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-playfair font-semibold text-gray-900">
                      {item.name}
                    </h3>
                    <span className="text-xs px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full font-medium">
                      {categories.find(cat => cat.value === item.category)?.label || item.category}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 mb-4 text-sm">
                    {item.description}
                  </p>
                  
                  <div className="space-y-3 mb-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-1">Specifications:</p>
                      <div className="flex flex-wrap gap-1">
                        {item.specifications.slice(0, 2).map((spec, idx) => (
                          <span key={idx} className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                            {spec}
                          </span>
                        ))}
                        {item.specifications.length > 2 && (
                          <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                            +{item.specifications.length - 2} more
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium text-gray-700">Dimensions:</p>
                      <p className="text-xs text-gray-600">{item.dimensions}</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-yellow-600 font-semibold">
                      {item.price}
                    </span>
                    <Button 
                      size="sm" 
                      className="bg-yellow-600 text-white hover:bg-yellow-700"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                <Search className="text-gray-400" size={32} />
              </div>
              <h3 className="text-2xl font-playfair font-semibold text-gray-900 mb-2">
                No items found
              </h3>
              <p className="text-gray-600 mb-6">
                Try adjusting your search criteria or browse all categories.
              </p>
              <Button
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("all");
                  setSelectedRoom("all");
                }}
                className="bg-yellow-600 text-white hover:bg-yellow-700"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Download Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 to-black text-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-playfair font-bold mb-6">
              Download Complete <span className="gradient-text">Catalog</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Get our comprehensive furniture catalog with detailed specifications, 
              pricing, and design options for all collections.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-yellow-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-yellow-700 transition-all duration-300">
                <Download className="mr-2" size={20} />
                Download PDF Catalog
              </Button>
              <Button 
                variant="outline" 
                className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-gray-900 transition-all duration-300"
              >
                Request Physical Catalog
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Additional Collections */}
      <section className="py-20 bg-gradient-to-br from-stone-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
              Explore More <span className="gradient-text">Collections</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Each catalog showcases our dedication to design excellence, material quality, 
              and functional beauty — helping you visualize how our products can elevate your space.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Wallcoverings Collection",
                description: "Transform your walls into art with our premium wallcovering selection",
                items: "150+ Designs"
              },
              {
                title: "Carpets & Rugs",
                description: "Handpicked carpets and rugs that ground your interiors with warmth",
                items: "200+ Options"
              },
              {
                title: "Curtains & Fabrics",
                description: "Premium fabrics and tailored curtains for refined softness",
                items: "300+ Fabrics"
              }
            ].map((collection, index) => (
              <motion.div
                key={collection.title}
                className="furniture-card rounded-2xl p-8 text-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                whileHover={{ y: -8 }}
              >
                <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center">
                  <Download className="text-white" size={24} />
                </div>
                <h3 className="text-2xl font-playfair font-semibold text-gray-900 mb-4">
                  {collection.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {collection.description}
                </p>
                <p className="text-yellow-600 font-semibold mb-6">
                  {collection.items}
                </p>
                <Button className="bg-yellow-600 text-white hover:bg-yellow-700 w-full">
                  View Collection
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}