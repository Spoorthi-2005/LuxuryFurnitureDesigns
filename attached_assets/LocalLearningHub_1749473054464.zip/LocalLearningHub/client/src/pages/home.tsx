import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import CollectionsSection from "@/components/collections-section";
import ServicesSection from "@/components/services-section";
import CraftsmanshipSection from "@/components/craftsmanship-section";
import PortfolioSection from "@/components/portfolio-section";
import AboutSection from "@/components/about-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import ImageLightbox from "@/components/image-lightbox";
import { useState } from "react";

export default function Home() {
  const [lightboxImage, setLightboxImage] = useState<{ src: string; alt: string } | null>(null);

  return (
    <div className="min-h-screen overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <CollectionsSection onImageClick={setLightboxImage} />
      <ServicesSection />
      <CraftsmanshipSection />
      <PortfolioSection onImageClick={setLightboxImage} />
      <AboutSection />
      <ContactSection />
      <Footer />
      
      {lightboxImage && (
        <ImageLightbox
          src={lightboxImage.src}
          alt={lightboxImage.alt}
          onClose={() => setLightboxImage(null)}
        />
      )}
    </div>
  );
}
