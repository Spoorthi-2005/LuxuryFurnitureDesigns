import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { motion } from "framer-motion";
import { Award, Users, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useEffect, useState } from "react";

export default function About() {
  const [projectsCount, setProjectsCount] = useState(0);
  const [craftsmenCount, setCraftsmenCount] = useState(0);
  const [yearsCount, setYearsCount] = useState(0);

  useEffect(() => {
    const animateCounter = (target: number, setter: (value: number) => void) => {
      let current = 0;
      const increment = target / 100;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setter(Math.floor(current));
      }, 20);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateCounter(700, setProjectsCount);
            animateCounter(50, setCraftsmenCount);
            animateCounter(3, setYearsCount);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 }
    );

    const statsSection = document.getElementById("stats");
    if (statsSection) {
      observer.observe(statsSection);
    }

    return () => observer.disconnect();
  }, []);

  const expertise = [
    {
      title: "Contemporary Interior Design Excellence",
      description: "Since 2022, Blackhorse has established itself as a premium interior design and furniture specialist. Our vision is to create contemporary living spaces that blend modern aesthetics with exceptional craftsmanship and functionality."
    },
    {
      title: "Indian Craftsmanship Meets European Standards",
      description: "We collaborate with skilled artisans and modern manufacturing techniques to deliver exceptional interior solutions that combine contemporary design with reliable quality and innovative functionality."
    },
    {
      title: "End-to-End Design Solutions",
      description: "Our strength lies in delivering custom-built, contemporary furniture rooted in Indian craftsmanship, minimalistic and artistic design sensibilities tailored to each space, and complete interior solutions."
    }
  ];

  const founders = [
    {
      name: "Amar Chauhan",
      role: "Founder",
      description: "Visionary leader with deep expertise in furniture design and manufacturing",
      experience: "15+ years"
    },
    {
      name: "Diksha Shringi",
      role: "Co-Founder",
      description: "Interior design specialist focused on contemporary aesthetics and client experience",
      experience: "12+ years"
    }
  ];

  const values = [
    {
      icon: Award,
      title: "Excellence in Craftsmanship",
      description: "Every piece reflects our commitment to superior quality and attention to detail"
    },
    {
      icon: Users,
      title: "Client-Centric Approach",
      description: "We partner closely with clients to deliver furniture solutions that elevate spaces"
    },
    {
      icon: MapPin,
      title: "Local Heritage, Global Standards",
      description: "Combining traditional Indian artistry with contemporary European design principles"
    },
    {
      icon: Clock,
      title: "Timeless Design Philosophy",
      description: "Creating spaces that speak to both lifestyle and legacy through form, texture, and space"
    }
  ];

  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-stone-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-6xl font-playfair font-bold text-gray-900 mb-6">
              About <span className="gradient-text">Blackhorse</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
              At Blackhorse, we believe furniture is not just about function — it's about feeling, form, and identity. 
              Born from a shared passion for design and detail, we create spaces that speak to both lifestyle and legacy.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
                Our <span className="gradient-text">Journey</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                What started as a design initiative has grown into a full-scale studio specializing in custom 
                Indian furniture, interior styling, and turnkey solutions. Guided by a deep respect for 
                minimalism, craftsmanship, and modern aesthetics, Blackhorse creates spaces that speak to 
                both lifestyle and legacy.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Our focus lies in delivering European-standard quality with Indian artistry — combining 
                structure, precision, and styling in every detail. From residential to commercial projects, 
                we offer not just furniture, but end-to-end design journeys tailored to each client's vision.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                At Blackhorse, we don't follow trends — we shape timeless experiences through form, texture, and space.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img
                src="https://images.unsplash.com/photo-1503602642458-232111445657?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                alt="Furniture artisans at work in modern workshop"
                className="w-full h-auto rounded-2xl shadow-2xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-6">
              Our <span className="gradient-text">Impact</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              className="text-center p-8 bg-gradient-to-br from-yellow-600/20 to-amber-600/20 rounded-xl backdrop-blur-sm"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-5xl font-bold text-yellow-400 mb-2">
                {yearsCount}+
              </div>
              <div className="text-xl text-gray-300">Years of Excellence</div>
            </motion.div>
            
            <motion.div
              className="text-center p-8 bg-gradient-to-br from-yellow-600/20 to-amber-600/20 rounded-xl backdrop-blur-sm"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-5xl font-bold text-yellow-400 mb-2">
                {projectsCount}+
              </div>
              <div className="text-xl text-gray-300">Projects Completed</div>
            </motion.div>
            
            <motion.div
              className="text-center p-8 bg-gradient-to-br from-yellow-600/20 to-amber-600/20 rounded-xl backdrop-blur-sm"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-5xl font-bold text-yellow-400 mb-2">
                {craftsmenCount}+
              </div>
              <div className="text-xl text-gray-300">Master Craftsmen</div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Founders Section */}
      <section className="py-20 bg-gradient-to-br from-stone-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
              Meet Our <span className="gradient-text">Founders</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Blackhorse is the vision of experienced professionals who together bring over 15 years 
              of experience in the world of premium furniture and interiors.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {founders.map((founder, index) => (
              <motion.div
                key={founder.name}
                className="furniture-card rounded-2xl p-8 text-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                whileHover={{ y: -8 }}
              >
                <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center">
                  <Users className="text-white" size={32} />
                </div>
                <h3 className="text-2xl font-playfair font-bold text-gray-900 mb-2">
                  {founder.name}
                </h3>
                <p className="text-yellow-600 font-semibold mb-4">{founder.role}</p>
                <p className="text-gray-600 mb-4">{founder.description}</p>
                <div className="text-sm text-gray-500 font-medium">{founder.experience}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
              Our <span className="gradient-text">Expertise</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              At Blackhorse, expertise is not just what we do — it's how we do it.
            </p>
          </motion.div>

          <div className="space-y-12">
            {expertise.map((item, index) => (
              <motion.div
                key={item.title}
                className="max-w-4xl mx-auto text-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                <h3 className="text-2xl font-playfair font-bold text-gray-900 mb-4">
                  {item.title}
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-6">
              Our <span className="gradient-text">Values</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              We don't just design interiors — we define them, one timeless piece at a time.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <motion.div
                  key={value.title}
                  className="text-center"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                >
                  <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center">
                    <IconComponent className="text-white" size={24} />
                  </div>
                  <h3 className="text-xl font-playfair font-semibold mb-3">
                    {value.title}
                  </h3>
                  <p className="text-gray-300">
                    {value.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-playfair font-bold text-gray-900 mb-6">
              Join Our Journey
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Experience furniture that transforms spaces and enriches lives through exceptional craftsmanship.
            </p>
            <Link href="/contact">
              <Button className="bg-yellow-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-yellow-700 transition-all duration-300">
                Start Your Project
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}