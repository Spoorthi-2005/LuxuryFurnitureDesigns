import { motion } from "framer-motion";
import { useState } from "react";
import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSubmissionSchema, type InsertContactSubmission } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertContactSubmission>({
    resolver: zodResolver(insertContactSubmissionSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      projectDetails: "",
    },
  });

  const submitContact = useMutation({
    mutationFn: async (data: InsertContactSubmission) => {
      return await apiRequest("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for contacting us! We'll get back to you within 24 hours.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again or call us directly.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContactSubmission) => {
    submitContact.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-amber-50 pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Contact <span className="text-amber-600">Us</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ready to transform your space with exquisite Indian furniture? 
            Get in touch with our expert team for personalized consultation.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16">
          
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Get in Touch</h2>
              
              {/* India Office */}
              <div className="bg-white rounded-2xl p-8 shadow-lg mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
                  <MapPin className="text-amber-600" size={20} />
                  India Office
                </h3>
                <div className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    Blackhorse Furnitures<br />
                    351, Khari Estate<br />
                    Sultanpur MG Road<br />
                    New Delhi - 110030
                  </p>
                  
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-center gap-3">
                      <Phone className="text-amber-600" size={18} />
                      <div>
                        <a href="tel:+919718978337" className="text-gray-900 hover:text-amber-600">
                          +91 97189 78337
                        </a>
                        <p className="text-sm text-gray-500">Amar Chauhan</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Phone className="text-amber-600" size={18} />
                      <div>
                        <a href="tel:+918826560644" className="text-gray-900 hover:text-amber-600">
                          +91 88265 60644
                        </a>
                        <p className="text-sm text-gray-500">Diksha Shiring</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Mail className="text-amber-600" size={18} />
                      <div>
                        <a href="mailto:amarchauhan1287@gmail.com" className="text-gray-900 hover:text-amber-600">
                          amarchauhan1287@gmail.com
                        </a>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Mail className="text-amber-600" size={18} />
                      <div>
                        <a href="mailto:dikshas2591@gmail.com" className="text-gray-900 hover:text-amber-600">
                          dikshas2591@gmail.com
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Italy Office */}
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
                  <MapPin className="text-amber-600" size={20} />
                  Italy Office
                </h3>
                <div className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    Frezza Arredamenti<br />
                    Viale Europa, 2<br />
                    36046 Lusiana, Vicenza<br />
                    Italy
                  </p>
                </div>
              </div>

              {/* Business Hours */}
              <div className="bg-gradient-to-r from-amber-600 to-amber-700 rounded-2xl p-8 text-white">
                <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                  <Clock size={20} />
                  Business Hours
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Monday - Saturday</span>
                    <span>9:00 AM - 7:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday</span>
                    <span>10:00 AM - 5:00 PM</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-white rounded-3xl p-10 shadow-xl"
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Send us a Message</h2>
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  {...form.register("fullName")}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-colors"
                  placeholder="Enter your full name"
                />
                {form.formState.errors.fullName && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.fullName.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  {...form.register("email")}
                  type="email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-colors"
                  placeholder="Enter your email address"
                />
                {form.formState.errors.email && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.email.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number
                </label>
                <input
                  {...form.register("phone")}
                  type="tel"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-colors"
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Project Details *
                </label>
                <textarea
                  {...form.register("projectDetails")}
                  rows={5}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-colors resize-none"
                  placeholder="Tell us about your project requirements, preferred styles, budget, and timeline..."
                />
                {form.formState.errors.projectDetails && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.projectDetails.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={submitContact.isPending}
                className="w-full bg-amber-600 text-white py-4 px-6 rounded-lg font-semibold hover:bg-amber-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300 flex items-center justify-center gap-2"
              >
                {submitContact.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-top-transparent"></div>
                    Sending...
                  </>
                ) : (
                  <>
                    <Send size={18} />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </motion.div>
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <div className="bg-white rounded-3xl p-12 shadow-xl">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Ready to Begin Your Journey?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Schedule a consultation with our design experts and bring your vision to life
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:+919718978337"
                className="bg-amber-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-amber-700 transition-colors duration-300 flex items-center justify-center gap-2"
              >
                <Phone size={18} />
                Call Now
              </a>
              <a
                href="https://wa.me/919718978337"
                target="_blank"
                rel="noopener noreferrer"
                className="border-2 border-amber-600 text-amber-600 px-8 py-4 rounded-full font-semibold hover:bg-amber-600 hover:text-white transition-colors duration-300"
              >
                WhatsApp Us
              </a>
            </div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}