import { motion } from "framer-motion";

export default function OurStory() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 to-amber-50 pt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Our <span className="text-amber-600">Story</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Three decades of excellence in Indian furniture craftsmanship, creating timeless pieces 
            that blend traditional artistry with contemporary design.
          </p>
        </motion.div>

        {/* Company Story */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-white rounded-3xl shadow-xl p-12 mb-20"
        >
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Blackhorse Furnitures
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                Established in 2020 with a vision to preserve and celebrate India's rich furniture-making heritage, 
                Blackhorse Furnitures has quickly become a leading name in luxury interior design. 
                We specialize in creating bespoke furniture pieces that tell stories through their intricate 
                craftsmanship and timeless appeal.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                Our journey began with a simple belief: every piece of furniture should be a work of art 
                that enhances the beauty of living spaces while reflecting the soul of Indian craftsmanship. 
                In just a few years, we have proudly completed 700 projects and serve discerning clients across India and internationally.
              </p>
              <div className="grid grid-cols-2 gap-8">
                <div className="text-center">
                  <div className="text-4xl font-bold text-amber-600 mb-2">700</div>
                  <div className="text-gray-600">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-amber-600 mb-2">2020</div>
                  <div className="text-gray-600">Established</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="/attached_assets/img8.png"
                alt="Blackhorse Furnitures Showroom"
                className="rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </motion.div>

        {/* Founders Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mb-20"
        >
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
            Meet Our <span className="text-amber-600">Founders</span>
          </h2>

          <div className="grid lg:grid-cols-2 gap-16">
            {/* Amar Chauhan */}
            <div className="bg-white rounded-3xl shadow-xl p-10 text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-4xl font-bold text-white">AC</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Amar Chauhan</h3>
              <p className="text-amber-600 font-medium mb-4">Founder & Creative Director</p>
              <p className="text-gray-600 leading-relaxed mb-6">
                The visionary founder behind Blackhorse Furnitures, Amar Chauhan established the company in 2020 
                with a dream to merge traditional Indian craftsmanship with contemporary design. His passion for 
                luxury furniture and deep understanding of client needs has driven the company's rapid growth.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Under his leadership, Blackhorse has completed 700 prestigious projects, establishing itself 
                as a premier destination for luxury furniture. Amar's commitment to quality and innovation 
                continues to set new standards in the furniture industry.
              </p>
              <div className="mt-6">
                <a 
                  href="mailto:amarchauhan1287@gmail.com"
                  className="text-amber-600 hover:text-amber-700 font-medium"
                >
                  amarchauhan1287@gmail.com
                </a>
              </div>
            </div>

            {/* Diksha Shiring */}
            <div className="bg-white rounded-3xl shadow-xl p-10 text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-4xl font-bold text-white">DS</span>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Diksha Shiring</h3>
              <p className="text-purple-600 font-medium mb-4">Co-Founder & Operations Director</p>
              <p className="text-gray-600 leading-relaxed mb-6">
                The strategic co-founder of Blackhorse Furnitures, Diksha Shiring joined Amar in 2020 
                to bring operational excellence and business acumen to the company. Her expertise in 
                client relations and project management has been crucial in delivering 700 successful projects.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Diksha's meticulous attention to detail and commitment to customer satisfaction ensures 
                that every piece of furniture meets the highest standards. Her leadership has been instrumental 
                in delivering 700+ successful projects, establishing long-term relationships with 
                clients across India and internationally.
              </p>
              <div className="mt-6">
                <a 
                  href="mailto:dikshas2591@gmail.com"
                  className="text-purple-600 hover:text-purple-700 font-medium"
                >
                  dikshas2591@gmail.com
                </a>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Values Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="bg-gradient-to-r from-amber-600 to-amber-700 rounded-3xl p-12 text-white text-center"
        >
          <h2 className="text-4xl font-bold mb-8">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="text-6xl mb-4">🎨</div>
              <h3 className="text-xl font-bold mb-2">Craftsmanship</h3>
              <p>Preserving traditional Indian artistry while embracing modern innovation.</p>
            </div>
            <div>
              <div className="text-6xl mb-4">✨</div>
              <h3 className="text-xl font-bold mb-2">Excellence</h3>
              <p>Uncompromising quality in every piece we create for our valued clients.</p>
            </div>
            <div>
              <div className="text-6xl mb-4">🤝</div>
              <h3 className="text-xl font-bold mb-2">Trust</h3>
              <p>Building lasting relationships through transparency and reliable service.</p>
            </div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}