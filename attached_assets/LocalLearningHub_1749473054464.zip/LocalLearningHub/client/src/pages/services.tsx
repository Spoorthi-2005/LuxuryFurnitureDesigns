import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { motion } from "framer-motion";
import { Hammer, Palette, Users, Truck, Settings, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Services() {
  const services = [
    {
      icon: Hammer,
      title: "Custom Furniture Design & Manufacturing",
      description: "Premium, handcrafted furniture built with minimalistic, contemporary, and artistic sensibilities. Each piece undergoes our standardized multi-step process from structural carpentry to final upholstery.",
      features: [
        "Structure (Carpentry): Strong, durable frames built with seasoned wood",
        "Polishing: Flawless finishes that enhance natural textures",
        "Foaming: High-density foams for superior comfort",
        "Upholstery: Hand-finished with premium fabrics"
      ]
    },
    {
      icon: Palette,
      title: "Interior Styling & Professional Consultation",
      description: "Tailored design advice for creating cohesive, well-balanced interiors aligned with your vision. Whether you're designing a new home or upgrading a space, our experts guide you through every step.",
      features: [
        "Layout planning and space optimization",
        "Furniture selection and coordination",
        "Material coordination and sourcing",
        "Theme alignment from concept to installation"
      ]
    },
    {
      icon: Users,
      title: "Premium & Standardized Products",
      description: "European-standardized quality through thoughtful material selection, design efficiency, and consistent quality checks. Every piece is refined, reliable, and ready to impress.",
      features: [
        "European-grade quality standards",
        "Consistent quality control processes",
        "Premium material selection",
        "Design efficiency optimization"
      ]
    }
  ];

  const additionalServices = [
    {
      icon: Settings,
      title: "Wallcoverings",
      description: "Transform your walls into art. Our wallcoverings go beyond paint — offering texture, pattern, and personality to every surface.",
      details: "From subtle weaves to bold designer prints, each selection is crafted to enhance space with elegance and depth."
    },
    {
      icon: Award,
      title: "Carpets & Rugs",
      description: "Soft underfoot. Strong in style. We offer a range of handpicked carpets and rugs that ground your interiors with warmth.",
      details: "Choose from modern minimal textures to traditional patterns — all curated for aesthetic balance and durability."
    },
    {
      icon: Truck,
      title: "Curtains & Fabrics",
      description: "Dress your space with refined softness. Our collection of premium fabrics and tailored curtains adds flow and sophistication.",
      details: "With a focus on quality materials and versatile styles, we help you find the perfect finish to tie your interiors together."
    }
  ];

  const processSteps = [
    {
      step: "01",
      title: "Consultation",
      description: "Initial meeting to understand your vision, space, and requirements"
    },
    {
      step: "02", 
      title: "Design Development",
      description: "Creating detailed designs and material selections based on your preferences"
    },
    {
      step: "03",
      title: "Manufacturing",
      description: "Skilled craftsmen bring designs to life using premium materials and techniques"
    },
    {
      step: "04",
      title: "Delivery & Installation",
      description: "Door-to-door delivery with professional setup and post-installation support"
    }
  ];

  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-gray-900 to-black text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-6xl font-playfair font-bold mb-6">
              Our <span className="gradient-text">Services</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
              At Blackhorse, we offer comprehensive design and execution services that bring elegance 
              and functionality into every space. From concept to creation, every detail is thoughtfully 
              crafted to suit modern spaces while delivering end-to-end interior solutions.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="space-y-16">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <motion.div
                  key={service.title}
                  className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                    index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
                  }`}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <div className={index % 2 === 1 ? 'lg:col-start-2' : ''}>
                    <div className="w-16 h-16 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center mb-6">
                      <IconComponent className="text-white" size={32} />
                    </div>
                    <h3 className="text-3xl font-playfair font-bold text-gray-900 mb-4">
                      {service.title}
                    </h3>
                    <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                      {service.description}
                    </p>
                    <ul className="space-y-3">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <div className="w-2 h-2 bg-yellow-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className={index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}>
                    <img
                      src={`https://images.unsplash.com/photo-${
                        index === 0 ? '1586023492125-27b2c045efd7' : 
                        index === 1 ? '1560448204-61dc36dc9d12' : 
                        '1503602642458-232111445657'
                      }?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600`}
                      alt={service.title}
                      className="w-full h-auto rounded-2xl shadow-2xl"
                    />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-gradient-to-br from-stone-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-gray-900 mb-6">
              Complete Interior <span className="gradient-text">Solutions</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We deliver end-to-end interior solutions that blend style, structure, and service — all under one roof.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {additionalServices.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <motion.div
                  key={service.title}
                  className="furniture-card rounded-2xl p-8 text-center"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  whileHover={{ y: -8 }}
                >
                  <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center">
                    <IconComponent className="text-white" size={32} />
                  </div>
                  <h3 className="text-2xl font-playfair font-semibold text-gray-900 mb-4">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {service.description}
                  </p>
                  <p className="text-sm text-gray-500">
                    {service.details}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-playfair font-bold mb-6">
              Our <span className="gradient-text">Process</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              From our workshop to your doorstep, we handle everything — delivery, installation, 
              and post-installation support — so you can focus on living beautifully.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <motion.div
                key={step.step}
                className="text-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-yellow-600 to-amber-600 rounded-full flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{step.step}</span>
                </div>
                <h3 className="text-xl font-playfair font-semibold mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-300">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-playfair font-bold text-gray-900 mb-6">
              Ready to Start Your Project?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Let our experts guide you through tailored interior and styling consultations.
            </p>
            <Link href="/contact">
              <Button className="bg-yellow-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-yellow-700 transition-all duration-300">
                Book a Free Consultation
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}